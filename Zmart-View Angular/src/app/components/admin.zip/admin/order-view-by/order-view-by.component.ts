import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Order } from 'src/app/models/Order';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-order-view-by',
  templateUrl: './order-view-by.component.html',
  styleUrls: ['./order-view-by.component.css']
})
export class OrderViewByComponent implements OnInit {

  order:Order;
  orderList:Order[]=[];
  submitted:boolean = false;
  form1:FormGroup;
  form2:FormGroup;
  form3:FormGroup;
  form4:FormGroup;

  constructor(private fb:FormBuilder,
              private router:Router,
              private orderService:OrderService) {

     }

  ngOnInit(): void {

    this.form1=this.fb.group({
      userId:['',[Validators.required]]
    });
    this.form1=new FormGroup({
      orderId:new FormControl('',[Validators.required])
    });
    this.form1=this.fb.group({
      orderDate:['',[Validators.required]]
    });
    this.form1=this.fb.group({
      status:['',[Validators.required]]
    });
  }
  get f1(){
    return this.form1.controls;
  }
  get f2(){
    return this.form2.controls;
  }
  get f3(){
    return this.form3.controls;
  }
  get f4(){
    return this.form4.controls;
  }
  getByStatus(){
     this.submitted=true;
     if(!this.form4.valid)
      return;
      
  }
  getByOrderId(){
    this.submitted=true;
    if(!this.form2.valid){
      return;
    }
      this.orderService.getOrderByOrderId(this.form2.controls.orderId.value).subscribe(
        (data)=>{
          if(data!=null){
            console.log(data);
            this.orderList.push(data);
          }
        }
      )


  }
  getByUserId(){
    this.submitted=true;
    if(!this.form1.valid)
      return;
  }
  getByDate(){
    this.submitted=true;
    if(!this.form3.valid)
      return;
  }
}
