import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import { Order } from '../models/Order';
import { Status } from '../models/status.enum';
import { CartItemModel } from '../models/CartItemModel';
@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private bookingUrl=`http://localhost:8021/order`;
  private order: Order;
  private orderList:Order[]=[];
 //private orderId:number;
  constructor(private http:HttpClient) {

   }

   placeOrder(order):Observable<any> {
     console.log(order);
     return this.http.post(`${this.bookingUrl}`,order);
   }
   getOrderByOrderId(orderId:number):Observable<any>{
      return this.http.get(`${this.bookingUrl}/orders/orderId/${orderId}`);
   }

   getAllOrders():Observable<any> {

    return this.http.get(`${this.bookingUrl}/orders`);
   }

   getOrdersByUserId(userId:number):Observable<any>{
     return this.http.get(`${this.bookingUrl}/orders/userId/${userId}`)
   }

   getOrdersByOrderDate(orderDate:Date):Observable<any>{
     return this.http.get(`${this.bookingUrl}/orders/orderDate/${orderDate}`)
   }

   updateOrder(orderId:number,status:string):Observable<any>{
     return this.http.put(`${this.bookingUrl}/orders/updateOrder/${orderId}/${status}`,{});
   }

   setOrder(cartItem:CartItemModel[], discountedPrice:number)
   {   let order={orderId:null,
                  userId:null,
	                amount:null,
	                orderDate:null,
	                deliveryDate:null,
                  orderItems:[],
                  status:null,
                  paymentType:null,
                  address:null,
                  contact:null};
        let amount=0;
        this.order=order;
     //  console.log(cartItem);
      // console.log(this.order);
       for(let i=0;i<cartItem.length;i++){
        let value=cartItem[i];
            let item={id:null,
              productId:value.productId,
              price:value.price,
              quantity:value.quantity,
              productName:value.productName};
              amount=amount+value.quantity*value.price;
        
         // console.log(item);
         this.order.orderItems.push(item);
       }
       this.order.amount=discountedPrice;
       this.order.userId=Number(localStorage.getItem('id'));
     // console.log(this.order);
   }

   getOrder(): Order{
     return this.order;
   }
}
