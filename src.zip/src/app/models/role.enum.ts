export enum Role {
  User = 'ROLE_CUSTOMER',
  Admin = 'ROLE_MERCHANT'
}
