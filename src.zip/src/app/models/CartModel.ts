import { CartItemModel } from "./CartItemModel";

export class CartModel
{
    public userId:number;
	public cartItem:CartItemModel[];
}