export class ErrorResponse {
  status: boolean;
  message: string;
  constructor() {
  }
}
