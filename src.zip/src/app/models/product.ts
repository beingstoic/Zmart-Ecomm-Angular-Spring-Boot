
export class Product {
        id: number;
        productName: string;
        productDescription: string;
        unitPrice: number;
        imageUrl: string;
        productQuantity: number;

}