export enum Status{
    BOOKED,
    DISPATCHED,
    DELIVERED,
    CANCELLED
}