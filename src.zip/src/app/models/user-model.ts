import { Role } from "./role.enum";

export class UserModel {

	public userId:number;

    public firstName:string;
	
	public lastName:string ;

	public email:string ;
	
	public mobile:string ;
	
	public username:string ;

}
