export class RegisterModel {
    public firstName:string;
	
	public lastName:string ;

	public email:string ;
	
	public mobile:string ;
	
    public username:string ;

    public password:string;
    
    public role: string;
    
    public gender:string;
}
