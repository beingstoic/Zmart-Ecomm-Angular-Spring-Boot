export class CartItemModel
{
    public cartItemId:number;
	public productId:number;
	public price:number;
	public productName:string;
	public quantity:number;
}