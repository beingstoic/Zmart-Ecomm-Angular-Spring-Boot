import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ErrorResponse } from 'src/app/models/error-response';
import { Order } from 'src/app/models/Order';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-order-view-by',
  templateUrl: './order-view-by.component.html',
  styleUrls: ['./order-view-by.component.css']
})
export class OrderViewByComponent implements OnInit {

  order:Order;
  orderList:Order[]=[];
  submitted:boolean = false;
  form1:FormGroup;
  form2:FormGroup;
  form3:FormGroup;
  form4:FormGroup;
  success:boolean = false;
  fail:boolean = false;
  response: ErrorResponse = new ErrorResponse();
  constructor(private fb:FormBuilder,
              private router:Router,
              private orderService:OrderService) {


     }

  ngOnInit(): void {

    this.form1=this.fb.group({
      userId:['',[Validators.required]]
    });
    this.form2=new FormGroup({
      orderId:new FormControl('',[Validators.required])
    });
    this.form3=this.fb.group({
      orderDate:['',[Validators.required]]
    });
    this.form4=this.fb.group({
      status:['',[Validators.required]]
    });
  }
  get f1(){
    return this.form1.controls;
  }
  get f2(){
    return this.form2.controls;
  }
  get f3(){
    return this.form3.controls;
  }
  get f4(){
    return this.form4.controls;
  }
  getByStatus(){
     this.submitted=true;
     if(!this.form4.valid)
      return;
      
  }
  getByOrderId(){
    this.submitted=true;
    this.orderList=[];
    this.response={status:false,message:''};
    console.log(this.form2.valid);
    if(!this.form2.valid)
    {
      return;
    }
      this.orderService.getOrderByOrderId(Number(this.form2.controls.orderId.value)).subscribe(
        (data)=>{
          if(data!=null){
            console.log(data);
            this.orderList.push(data);
          }
        },(error)=>{
          console.log(error.error);
          this.response={status:true,message:error.error};
        });
      
     


  }
  getByUserId(){
    console.log("in get by user id")
    this.orderList=[];
    this.response={status:false,message:''};
    this.submitted=true;
    console.log(this.form1.valid);
    if(!this.form1.valid)
    {  return;
    }
    this.orderService.getOrdersByUserId(Number(this.f1.userId.value)).subscribe(
      data=>{
        if(data.length>0){
          data.forEach((value)=>{this.orderList.push(value);})
        }
        else{
          this.response={status:true,message:"No Orders Found"};
        }
      },(error)=>{
        console.log(error.error);
        this.response={status:true,message:error.error};
      }
    );

  }
  getByDate(){
    this.submitted=true;
    this.orderList=[];
    this.response={status:false,message:''};
    if(!this.form3.valid){
         return;
    }
    this.orderService.getOrdersByOrderDate(this.form3.controls.orderDate.value).subscribe(
      (data)=>{
        if(data.length>0){
          data.forEach((value)=>{this.orderList.push(value);})
        }else{
          this.response={status:true,message:"No orders found for this date"};
        }
      },(error)=>{
        console.log(error.error);
        this.response={status:true,message:error.error};
      });
    
  }

  viewOrderDetails(index:number){
    console.log(index);
      this.router.navigate(['/order',this.orderList[index].orderId]);
  }
}
